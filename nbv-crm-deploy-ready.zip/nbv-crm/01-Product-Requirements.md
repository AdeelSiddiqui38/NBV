# Next Bridge Ventures (NBV) — Immigration CRM
## Product Requirements Document (PRD) — v2.0 (C11-focused)
**Date:** June 12, 2026 | **Prepared for:** Next Bridge Ventures, www.nextbridgeventures.ca
**System type:** Internal (staff-only) CRM & Case Management
**Primary business:** **C11 entrepreneur work permits** (IMP, LMIA-exemption R205(a) — "Business owners seeking only temporary residence"), where NBV:
1. Prepares a **business proposal / business plan** for each client and submits it for approval,
2. **Incorporates a new Canadian company** for each client,
3. **Opens a corporate bank account** for each client's company,
4. Files the Employer Portal offer of employment + the C11 work permit application,
5. Supports business establishment, WP extensions, and downstream PR strategy (PNP entrepreneur etc.).

---

## 1. Vision

One master file per client that tracks the **entire C11 venture lifecycle** — the person, the
business proposal (every draft and version), the corporation (incorporation documents, share
structure, BN/CRA accounts), the corporate bank account (opening, capital deposits, dual-funding
evidence), the immigration application (Employer Portal A-number, work permit, deadlines), and
all money (NBV invoices, trust ledger, government/third-party fees) — so nothing falls through
the cracks, the firm is CICC audit-ready, and every refusal risk is managed proactively.

### What makes the NBV CRM different from generic immigration CRMs
Officio/CaseEasy track "a case with documents." NBV's product is really **three deliverables per
client** that generic tools have no first-class concept for:

| NBV deliverable | First-class CRM object |
|---|---|
| Business proposal/plan (drafted, reviewed, versioned, submitted) | **Business Proposal** workspace with version control, review gates, financial-projection data |
| New incorporated company (federal or provincial) | **Corporate Entity register** — name reservation, articles, share structure (≥51% client-owned), BN, minute book, registered office, annual return dates |
| Corporate bank account + capital | **Banking & Capital tracker** — bank, account status, business capital deposited, personal/support funds evidence (2025 dual-funding rule), source-of-funds documents |

---

## 2. C11 regulatory context the system MUST encode (post-May 27, 2025 rules)

| Rule | System behaviour |
|---|---|
| **≥ 51% ownership** required for the applicant | Share structure validator on the Corporate Entity: warns if client ownership < 51%; multiple owners → only one C11 applicant per business flag. **With NBV equity partnerships, NBV's stake is auto-capped at ≤49% so the client always keeps ≥51%** |
| **RCIC conflict-of-interest rules** when NBV invests in a client's business | Partnership module enforces: written disclosure → ILA recommendation (confirmation/waiver) → written client consent → only then can shares be issued. All steps on the locked timeline |
| **Max 18-month permit validity** | WP validity tracker; auto-reminders at T-6/T-3 months for extension-or-exit strategy; extension case type with "business progress evidence" checklist |
| **Dual funding (separate business capital + personal LICO support funds)** | Two distinct funds checklists; business funds must trace to the **corporate** bank account, personal funds to personal accounts; combined-account warning |
| **Concrete significant benefit evidence** (jobs with titles/salaries/timelines, Canadian suppliers, regional development, innovation) | Structured "Benefit Plan" section in the Business Proposal object: planned hires (title, NOC/TEER, salary, start quarter), supplier commitments, location rationale |
| **Temporary intent** (this stream is for temporary residence; dual-intent → PNP entrepreneur/SUV advice) | Mandatory "intent strategy" advice entry at onboarding (locked advice log); PR pathway recorded as a separate linked case when pursued |
| **C11 experience does NOT count toward CEC** | Hard-coded advisory note on every C11 case; PR strategy module excludes CEC for C11 time |
| **Spousal OWP only if role is TEER 0/1** | Role/NOC field on the offer of employment; spouse OWP eligibility auto-flag |
| **Employer Portal offer + $230 compliance fee → A-number** | Employer Portal tracker per case: offer submitted date, compliance fee paid, **A-number** (required before WP filing — gate) |

Plus all CICC requirements from v1 (file opens at retainer, client account/trust ledger,
6-year retention, locked advice entries, audit pack export) — unchanged and still in scope.

---

## 3. Users, Login & Roles (multi-user from day one, built for growth)

### Authentication — individual login ID + password for every employee/consultant
- **One account per person — no shared logins ever** (CICC accountability + clean audit trail).
- Login = email address + password. **Password policy:** minimum 12 characters, complexity
  check against breached-password lists, no reuse of last 5, bcrypt/argon2 hashing —
  passwords are never stored or visible in plain text, not even to the Admin.
- **MFA (TOTP authenticator app) mandatory** for Admin/RCIC, optional-but-encouraged for
  others (Settings toggle to enforce firm-wide).
- Self-service **password reset** via email link (time-limited, single-use); Admin can force
  a reset but can never see a password.
- **Session security:** auto-logout after inactivity (default 30 min, configurable),
  "remember this device" optional, concurrent-session list with remote sign-out
  ("log out my stolen laptop"), login-attempt throttling + lockout after 5 failures,
  new-device/new-location login alerts.
- **Login audit:** every successful/failed login, IP, device recorded in the activity log.
- Future growth ready (Phase 2/3): SSO (Google Workspace / Microsoft 365), IP allow-listing
  per role, passkeys/WebAuthn.

### User lifecycle management (Admin screen)
- **Invite flow:** Admin enters name + email + role → invitation email → user sets own
  password + MFA on first login. No password ever communicated by chat/email.
- **Deactivation (offboarding):** one click → account disabled instantly, sessions killed,
  tasks/cases flagged for reassignment (guided reassignment wizard). Records are **never
  deleted** — a departed user's history stays on every file (CICC: who did what, when).
- Role changes take effect immediately and are themselves audit-logged.
- **Seat-based design:** unlimited users supported; per-user activity metrics (cases touched,
  tasks completed, docs filed, time logged) feed staff workload and performance views.

### Roles & permissions (RBAC)
| Role | Description | Permissions |
|---|---|---|
| **Admin / Owner** | NBV principal | Everything: user management, fee schedule & discount authority, partnerships approval, expense approvals, reports, settings |
| **RCIC / Consultant** | Licensed consultant | Full case work, sign-off gates (proposal/WP/extension), trust approvals, advice entries, discounts ≤15%, sensitive-field reveal |
| **Case Manager / Admin staff** | Document collection, scheduling, data entry | All case work except sign-off gates, trust approval, fee changes; quotes at list price only |
| **Business Plan Writer** | Internal or contractor | Business Proposal workspaces + repository folders 03/04/07 only; no immigration forms, no financials, no sensitive ID fields |
| **Accountant** | Bookkeeping | Billing, expenses, year-end package, repository folder 12; read-only elsewhere; no case edits |
| *(custom roles, Phase 2)* | e.g., Marketing, Reception | Granular permission matrix per module |

Every action by every user is written to the **immutable audit log** (who, what, when,
before/after) — the system's accountability backbone, and each record everywhere shows
"created by / last updated by" with the user's name.

---

## 4. Functional Modules

### M1 — Leads & Intake (C11-qualified funnel)
- Capture: name, country, net worth band, **business idea / sector**, management experience,
  funds available (business capital + settlement funds), English ability, family size.
- **C11 pre-qualification scorecard** (auto-computed): ownership/control feasible ≥51%? business
  capital adequate for sector? credible management background? benefit-to-Canada angle
  (jobs/region/innovation)? temporary-intent story viable? → Green / Amber / Red rating with notes.
- Lead stages: New → Discovery Call → Paid Consultation (ICA) → Feasibility Assessment Sent →
  **Quote Sent → Fee Agreed** → Retainer Sent → Won/Lost. Lost-reason analytics (price, weak
  funds, ineligible, competitor) — price losses link back to the declined quote for analysis.

### M1.5 — Fee Quotation & Negotiation ⭐ (new — pre-onboarding gate)

NBV's standard service fee is **CAD $30,000 per client (list price)** — negotiable per market
and client circumstances. The system makes the negotiation explicit, controlled, and final
**before** onboarding:

- **Fee schedule in Settings:** list price $30,000 (versioned — price changes don't affect
  past deals); optional component breakdown (C11 professional fees, business plan,
  incorporation, bank facilitation) for itemized quotes; standard disbursements estimate
  shown separately (govt fees, NUANS, translations — never discounted silently).
- **Quote object per lead:** list price → adjustments → **final agreed fee**:
  - Adjustment types: % discount, fixed reduction, scope reduction (component removed),
    market adjustment, partnership consideration (mode B/C fee reduction for equity),
    payment-plan premium/discount.
  - Every adjustment line requires a **reason** (competitor price, market conditions, client
    budget, referral courtesy, equity consideration...) — reasons are reportable.
- **Discount authority matrix (Settings):** e.g., Case Manager may quote list only; RCIC may
  approve up to 15% off; discounts >15% or below a **floor price** (e.g., $22,000) require
  Admin/Owner approval. Out-of-authority quotes are blocked pending approval.
- **Quote lifecycle:** Draft → Sent → Negotiating (counter-offers logged as quote versions) →
  **Agreed (client acceptance recorded: email/signature/date)** → Expired/Declined.
  Quotes auto-expire (default 30 days) so stale prices don't get honoured accidentally.
- **⛔ Onboarding gate:** a lead cannot convert to Client / no retainer can be generated
  unless an **Agreed quote** exists. The agreed fee auto-populates the retainer agreement,
  the milestone payment plan (% splits applied to the agreed amount), and all invoices —
  one source of truth; no manually-typed fee amounts anywhere downstream.
- **Post-retainer changes:** any later fee change = formal **retainer addendum** (RCIC
  approval + client written consent + logged reason). No silent edits.
- **Reporting:** average realized fee vs list, total discounts given by reason/by staff,
  discount % trend, win rate by quote level (does discounting actually win deals?),
  realized fee by engagement mode (A/B/C) and by sector/market.

### M2 — Clients, Family & Contacts ⭐ (expanded — every applicant comes with family)

#### Family composition capture (mandatory at onboarding)
Every client record carries a **Family Panel** — the household is captured once and reused
everywhere (forms, funds calculations, companion applications):

- **Members:** spouse/common-law partner, dependent children (eligibility auto-checked
  against the dependent-child definition: under 22 and unmarried, or 22+ and dependent due
  to a physical/mental condition), and non-accompanying relatives where needed for
  family-information forms.
- **Per-member bio data:** full name (+ native script), DOB, place/country of birth,
  citizenship(s), passport (number/issue/expiry — encrypted, expiry tracked), marital
  status, relationship to principal, address, occupation/school grade, prior Canadian
  status/visas, prior refusals (any country), UCI if exists.
- **Accompanying vs non-accompanying flag** per member — drives checklists, fees, medicals,
  biometrics, and the LICO line.
- **Relationship evidence:** marriage certificate, birth certificates, custody/consent
  orders for children of previous relationships, adoption papers → repository folder 02.
- **Family tree view** on the client profile; one update (new baby, passport renewal)
  propagates to all open cases and pending forms.

#### What the family data drives automatically
| Driver | System behaviour |
|---|---|
| **LICO / settlement funds** | Family size (principal + accompanying) auto-computes the required personal-funds line in the dual-funding checklist; recalculates if composition changes |
| **Spouse OWP companion case** | Client role TEER 0/1 → spouse flagged eligible; one click opens a linked Spouse OWP case pre-filled from the member record |
| **Children's status** | Per child: study permit (school-age; school-enrolment evidence task) or visitor record (younger); post-landing school-registration tasks |
| **Per-member document checklists** | Each accompanying member gets their own checklist: passport, photos, police certificates (per age/country rules), medicals if required, biometrics (ages 14–79), translations |
| **Government fees calculator** | Per-family totals: WP $155 + spouse OWP $255 + study permit $150/child + biometrics (individual $85 / family cap $170) — fee table editable in Settings |
| **IRCC family forms** | Family Information form (IMM 5707/5645 as applicable) pre-filled from member records; statutory questions tracked per member |
| **Medicals & biometrics tracker** | Per-member rows (booked/done/passed, eMedical #); family biometrics appointments grouped; expiries per member |
| **Deadlines & expiries** | Member passports/PCCs/medicals feed the expiry radar; alerts for a child approaching 22 (dependent-age lock) or reaching school age |
| **Post-approval family bundle** | Landing plan (together/staggered), SINs for adults, health cards, school registration, spouse job-search support if OWP |

#### Family-aware case views
- Case header shows a **family strip**: principal + each member with status icons
  (📋 docs % · 🩺 medical · 🔐 biometrics · ✈ visa issued).
- Companion cases (Spouse OWP, child study/visitor) are **linked cases sharing the family
  data** — one household, many applications, single source of truth.
- **Cross-case consistency checker:** warns when forms across the family disagree
  (addresses, dates, name spellings) — a common refusal trigger, prevented.
- Family contact log — entries tagged to whichever member called/wrote.

#### Plus the original client features
Entrepreneur profile (prior businesses, net worth, source-of-funds summary, management CV),
contact log with locked advice entries, PIPEDA consent, client-level shared documents.

### M3 — Cases
- **Case types (Phase 1):**
  1. **C11 Work Permit — New Business** (the flagship; full pipeline in 02-Process-Workflows)
  2. **C11 Work Permit — Business Purchase** (variant checklist: share/asset purchase agreement, valuation, vendor due diligence)
  3. **C11 Extension** (business progress evidence: financials, payroll records, hires made vs proposal, exit/succession plan)
  4. Spouse OWP (companion case)
  5. Dependent child study/visitor (companion case)
  6. **PR transition** (PNP Entrepreneur streams / other; linked follow-on case)
  7. Custom
- Case record: file # (`NBV-2026-####`), responsible RCIC, case manager, plan writer,
  linked Corporate Entity, linked Business Proposal, Employer Portal record, key dates
  (offer A-number date, WP submitted, biometrics, decision, **WP expiry**, extension trigger dates).

### M4 — Business Proposal Workspace ⭐ (new, core)
- One proposal per case, with **versioned drafts** (v0.1 outline → v1.0 client-approved →
  v1.x revisions → FINAL as-submitted PDF locked with hash).
- Structured sections so data is reusable in forms and reports:
  - Business concept, sector (NAICS), location (province/city + regional-benefit rationale)
  - Market analysis summary & competitors
  - **Financial projections** (3-year revenue/expense/cash-flow table — stored as data, not just PDF)
  - **Investment & capital plan** (total capital, source of funds, spent vs committed)
  - **Job creation plan**: each planned hire = title, NOC/TEER, salary, FTE, start quarter
    (this drives the "significant benefit" evidence and later extension-proof tracking)
  - Client's role & duties (NOC/TEER for spouse-OWP flag), org chart
  - Temporary-intent / exit narrative
- Workflow states: **Outline → Drafting → Internal Review → Client Review → Client Approved →
  Final (locked) → Submitted with WP application**.
- Review gates: plan writer → case manager QA → **RCIC sign-off (mandatory)** → client approval
  (recorded with date/method). Every state change on the timeline.
- Template library: per-sector proposal skeletons (restaurant, trucking, IT services, retail,
  cleaning/janitorial, construction trades, e-commerce...) — reusable boilerplate + required
  evidence list per sector.

### M5 — Corporate Entity Register ⭐ (new, core)
Per client company, tracks the **incorporation pipeline** and the ongoing corporate record:
- **Formation pipeline:** Name options → NUANS/name reservation → Articles filed
  (jurisdiction: federal CBCA or province) → Certificate of Incorporation received →
  Organizational resolutions/minute book → **CRA Business Number** + program accounts
  (RC corporate tax, RP payroll, RT GST/HST) → Registered office & agent → Extra-provincial
  registration (if needed).
- **Share structure table:** shareholder, class, #shares, % — with **51% rule validator**.
- Corporate documents vault: articles, certificate, bylaws, registers, share certificates,
  director consents — versioned + hashed.
- **Compliance calendar:** annual return due date, corporate tax year-end, GST/HST filing
  frequency, payroll remittance start (auto-reminders; these also feed C11 extension evidence).
- Links: → Business Proposal, → Bank account(s), → the C11 case, → invoices for incorporation
  service fees & disbursements (govt filing fees, NUANS, registered agent).

### M6 — Banking & Capital Tracker ⭐ (new, core)
- Per corporation: bank, branch, account type, **status pipeline**
  (Bank selected → Appointment booked → Docs submitted → Account opened → Capital deposited →
  Void cheque/confirmation on file).
- **Capital ledger (client's business funds — informational, not NBV trust):** transfers in
  (date, amount, source, FX rate, remitter), running balance, linked source-of-funds documents
  (sale deeds, savings statements, gift deeds) — produces the **dual-funding evidence pack**:
  - Business capital → corporate account statements
  - Personal/LICO support funds → personal account evidence (stored on client profile)
- Clear separation in UI: **client's business money ≠ NBV trust money** (different modules,
  different ledgers, different colours).

### M6.5 — Engagement Structure & NBV Partnership Module ⭐ (new)

Every case starts with a mandatory **Engagement Structure selector** (set at retainer,
changeable only with RCIC approval + logged reason):

```
ENGAGEMENT STRUCTURE (choose one)
 ○ A. SOLE OWNERSHIP (default)
      Client owns 100%. Client responsible for ALL costs
      (NBV professional fees, govt fees, incorporation, business capital).
      → No partnership records created; share validator expects client 100%.

 ○ B. PARTNERSHIP — WITH NBV FINANCIAL INVOLVEMENT
      Equity split selectable (e.g., 70:30, 60:40 — client:NBV; validator
      forces client ≥51%, NBV ≤49%, total = 100%).
      + COST-SPLIT MATRIX: for each cost category choose who pays and in
        what ratio (default = pro-rata to equity, fully overridable):
          · Incorporation & registration costs        e.g., 70/30
          · Government/IRCC fees                      e.g., client 100%
          · Business capital contribution             e.g., 70/30
          · Operating shortfall top-ups               e.g., 70/30
          · NBV professional fees                     full / reduced / waived
      → NBV capital contributions tracked, party-tagged in the capital
        ledger; distributions split per equity ratio.

 ○ C. PARTNERSHIP — NO NBV FINANCIAL INVOLVEMENT (sweat equity)
      Equity split selectable (client ≥51%), but NBV contributes $0.
      Client responsible for ALL costs and ALL business capital.
      NBV's equity consideration = services rendered (recorded explicitly
      in the retainer addendum + shareholder agreement).
      → Capital ledger expects CLIENT-tagged funds only; any NBV-tagged
        deposit raises a mismatch warning.
```

Each partnership deal (B or C) is a first-class object linked to the Corporate Entity:

- **Deal structure:** equity split, share classes per party, **financial-involvement flag**,
  cost-split matrix (B only), capital contribution by each party (amount, date, paid-in
  evidence), fee arrangement (full / reduced / waived professional fees — recorded in the
  retainer addendum and the partnership agreement).
- **Hard validators:**
  - Client total **≥ 51%** (C11 rule) → NBV stake capped **≤ 49%**; splits must total 100%.
  - Mode C (no financial involvement): NBV-tagged capital transactions blocked; consideration
    clause required in the shareholder agreement before shares can issue.
  - Mode B: each cost category must have a defined split before related invoices/disbursements
    can be posted; NBV-paid items are booked against NBV's contribution account, never the
    client's trust or the client's own-funds evidence.
  - Partnership (B or C) cannot reach "Shares Issued" until the **conflict-of-interest
    checklist** is complete: written disclosure of NBV's interest, client advised to obtain
    **independent legal advice (ILA)** (confirmation or informed written waiver), client's
    written consent, deal terms documented (CICC conflict-of-interest obligations).
- **Cost-split engine (Mode B):** every shared cost entered once → system computes each
  party's share, tracks who actually paid, and maintains an **inter-party balance**
  ("NBV owes / client owes") with settlement records.
- **Documents:** shareholder/partnership agreement (vesting, transfer restrictions, drag/tag,
  **buyout & exit terms**, dividend policy, services-consideration clause for Mode C),
  share subscriptions, director/officer appointments (NBV board seat? logged).
- **Ongoing tracking:** NBV capital committed vs paid (B), profit-distribution/dividend ledger
  (date, total, NBV share, client share, evidence), shareholder-loan ledger, annual valuation
  notes, exit events (buyback, sale, dilution) with full history.
- **Portfolio dashboard:** all NBV positions — company, %, mode (B/C), capital in,
  cost-split balance, distributions, book value, status (Structuring → COI Gate →
  Agreements → Shares Issued → Active → Exited).
- **Reporting:** per-deal P&L; firm-level "fee revenue vs equity income" split; CSV export
  for NBV's accountant.


### M7 — Immigration Application Tracker
- **Employer Portal panel:** employer (the new corp) enrolled, offer of employment drafted,
  job title/NOC/TEER/salary, offer submitted date, **$230 compliance fee paid**, **A-number**
  recorded. Gate: WP application cannot move to "Submitted" without an A-number.
- WP application: forms checklist, govt fees ($155 WP + biometrics $85), submission date,
  biometrics, medical (if required), ADR/procedural-fairness letters with deadline clocks,
  interview prep stage, decision (approved: **permit validity dates → 18-month cap tracker**;
  refused: auto-task bundle — reasons analysis, reapply vs judicial review advice with JR
  15/60-day clocks).
- **Post-landing & establishment stage:** arrival date, SIN obtained, business launched,
  first hire made, payroll started — milestones that become **extension evidence**.
- Extension radar: dashboard countdown per active permit (T-6 months: strategy meeting task;
  T-4: extension case opened or exit plan documented).

### M7.5 — Secure Document Repository ⭐ (new, core)

**One secured repository per case** (plus a client-level shared area for documents that span
cases, e.g., passports). Every file is classified, versioned, access-controlled, and retained
per CICC rules. No documents live in inboxes or desktop folders — the repository is the
single source of truth for the client file.

#### Standard folder taxonomy (auto-created when a case opens)
```
NBV-2026-0003 — Adeyemi, Maxwell (C11 New Business)
├── 01 Engagement & Agreements    retainer, ICA, addenda, IMM 5476, consents,
│                                 conflict-check record, partnership/COI docs (modes B/C)
├── 02 Identity & Personal        passport, photos, civil certificates, family docs
├── 03 Entrepreneur Profile       CV, prior-business proof, credentials, net-worth docs
├── 04 Business Proposal          drafts v0.x–v1.x, research annexes, FINAL (locked+hash)
├── 05 Corporate Records          NUANS, articles, certificate, bylaws, registers,
│                                 share certificates, minute book, CRA BN letters
├── 06 Banking & Financial        account confirmations, statements, capital wires/FX,
│                                 source-of-funds evidence, personal LICO funds
├── 07 Premises & Contracts       lease/LOI, supplier & customer contracts, insurance
├── 08 Employer Compliance        offer of employment, compliance-fee receipt, A-number
├── 09 IRCC Application           forms, fee receipts, submission letter, as-filed package
├── 10 IRCC Correspondence        AOR, biometrics letter, ADRs, decisions, permits
├── 11 Establishment & Extension  payroll records, T4s, financials, progress evidence
├── 12 Invoices & Receipts        NBV invoices, payments, disbursement proofs
└── 13 Notes & Internal           memos, call notes, working drafts (staff-only)
```
- Taxonomy is template-driven per case type (C11 New / Purchase / Extension / Spouse OWP…),
  adjustable in Settings; folders cannot be deleted while a case is open.
- **Client-level shared folder** for cross-case documents (passport, language tests) with
  links into each case — one renewal updates everywhere.

#### Filing discipline (how documents stay "properly filed")
- **Checklist-driven intake:** every checklist item maps to a target folder — marking an item
  "Received" prompts upload straight into the right folder with a standard name. No orphans.
- **Enforced naming convention:** `YYYY-MM-DD_<DocType>_<Party>_v<N>.<ext>` (auto-generated,
  e.g., `2026-06-08_PoliceCertificate_Adeyemi_v1.pdf`).
- **Required metadata on upload:** document type (controlled list), party (client / spouse /
  corporation / NBV), issue date, expiry date, language + translation flag, original-or-copy
  flag (originals also auto-logged in the Client Property Register, CICC s.5.3).
- **Inbox/triage queue:** files arriving via email-dropbox or scanner land in a per-case
  "Unfiled" queue; not "filed" until type + folder + metadata set. Dashboard shows unfiled
  counts per case — target zero.
- **Status lifecycle:** Requested → Received → Under Review → Approved → Submitted to IRCC →
  (Expired/Superseded). Approval records the reviewer's identity.

#### Versioning & integrity
- Re-uploads create new versions (v1, v2…); prior versions never deleted; SHA-256 hash per
  version (tamper evidence); metadata changes logged.
- **As-filed snapshots:** on submission to IRCC, the system freezes a read-only snapshot set
  ("exactly what went to IRCC on date X") — critical for ADRs, refusals, reapplications.
- Locked documents (FINAL business plan, signed retainer, advice letters) cannot be replaced —
  only superseded, with full history.

#### Security & access control
- Private encrypted object storage in **Canada region**; AES-256 at rest, TLS in transit;
  downloads via short-lived presigned URLs only — never public links.
- **Folder-level permissions by role:** Business Plan Writer → folders 03, 04, 07 only;
  Accountant → 12 only; folder 13 excluded from all client-facing exports. Per-document
  override for extra-sensitive items (RCIC-only).
- Every view / download / print written to the audit log (who, what, when).
- Optional watermark on downloaded PDFs ("NBV Confidential — file NBV-2026-0003").
- Virus scan on upload; file-type allowlist (pdf, jpg/png, docx/xlsx, eml/msg); 50 MB cap.

#### Retention, closing & export
- On case closing: repository flips to read-only **Closed File** mode, listed separately from
  active files (CICC), destruction date = close + 6 years; destruction needs Admin approval
  and produces a certificate-of-destruction record.
- **One-click exports:** complete case ZIP (folder structure + index PDF with hashes), CICC
  audit pack, or client-copy pack (excludes internal notes).
- **Expiry radar** across all open cases (passports, police certificates, medicals, bank
  statements going stale) with 90/60/30-day alerts.

### M8 — Billing, Invoices & Trust — as v1, with C11-specific extras
- **Service catalogue with bundled packages** (typical NBV engagement):
  e.g. Package = C11 Professional fees + Business plan preparation + Incorporation service +
  Bank account facilitation + Govt/third-party disbursements (NUANS, incorporation filing fee,
  compliance fee $230, WP fee $155, biometrics $85, translations).
- **Fees flow from the Agreed Quote** (M1.5): the negotiated amount (list $30,000 − approved
  adjustments) is the single source of truth — milestone plans apply % splits to the agreed
  fee (e.g., 30% retainer / 30% business plan approved / 25% incorporation + bank done /
  15% WP submission); invoices are generated from it; no free-typed fee amounts.
- Discounts shown explicitly on invoices if NBV chooses (list − discount = agreed) or rolled
  silently into the line price — per-client setting.
- CICC trust ledger, reconciliation statement, A/R aging, revenue by service line
  (immigration vs business-plan vs incorporation) — unchanged core from v1.

### M8.5 — NBV Earnings, Per-Client Profitability & CRA Year-End ⭐ (new)

#### Per-client earnings tracker ("how much does NBV make on each client?")
Every dollar in and out is tagged to a client/case, producing a live **per-client P&L**:

| Revenue side | Cost side |
|---|---|
| Professional fees invoiced & **collected** (from agreed quote) | Staff time cost (optional time-tracking at internal rates: RCIC, CM, plan writer hours) |
| Equity income — dividends/distributions from partnership deals (Modes B/C) | NBV's cost-split contributions (Mode B: incorporation share, capital top-ups expensed vs invested split) |
| Exit proceeds (buybacks/sales) vs capital invested = realized gains | Disbursements absorbed (not passed through) |
| Consultation fees (ICAs) | Referral/agent commissions paid on the file |
| | Refunds issued |

- **Views:** per client · per case · per engagement mode (A/B/C) · per sector · per source/agent ·
  per staff member; billed vs collected (accrual vs cash); margin % and ranking
  ("most/least profitable clients"); lifetime value per client across multiple cases.
- **Banking link:** NBV operating & trust accounts registered in Settings; every Payment and
  TrustTransaction records which NBV account it hit (e-transfer/wire/card ref) → monthly
  **bank-to-CRM matching report** (unmatched deposits flagged) — lightweight reconciliation
  even before full accounting-software sync.

#### CRA year-end tax package (NBV's own filings)
One-click **Year-End Package** export for NBV's accountant (fiscal-year selectable):
- **Revenue reports:** invoice register (date, client, service line, net, GST/HST, total,
  status), collected-payments register, revenue by service line mapped to **GL/GIFI-friendly
  categories** (editable chart-of-accounts mapping in Settings) — feeds the **T2** return.
- **GST/HST report:** tax collected per invoice per period, plus disbursement ITC summary —
  supports GST/HST returns (filing frequency reminder in compliance calendar).
- **Equity income schedule:** dividends received per partnership deal (T5 slips expected from
  each client corp — tracker shows expected vs received), realized gains on exits with ACB
  (adjusted cost base = NBV capital contributed, tracked per deal).
- **Trust handling:** unearned trust balances at year-end (liability, not income) clearly
  separated from earned revenue — prevents the classic consultant error of taxing trust money.
- **Expense side:** disbursement register with receipts (from the repository, folder 12),
  commissions paid register, cost-split outlays per deal.
- **Formats:** PDF summary + CSV per report + QuickBooks/Xero import files (Phase 2: live
  2-way sync). Plus NBV's own compliance calendar: T2 due date (6 months after year-end),
  GST/HST periods, T4/T5 slip deadlines (end of February), installment reminders.
- The same engine serves **client corporations** (Phase 2 service line): their compliance
  calendars already track T2/GST/payroll dates — exportable as a bookkeeping handoff pack.

### M8.6 — NBV Internal Expense Tracking ⭐ (new)

Tracks **NBV's own operating expenses** (not client disbursements, not cost-splits — those
live in their own modules). Goal: every business expense captured in seconds, categorized
automatically, GST/HST-ITC ready, and flowing into the CRA Year-End Package and true
profitability numbers.

#### Standard expense categories (chart of expense headers — editable in Settings, GIFI-mapped)
| Header | Examples |
|---|---|
| **Marketing & Advertising** | Google/Meta ads, SEO, content, print, expo/seminar booths, promotional webinars |
| **Referral & Commissions** | agent commissions (auto-fed from the Commission ledger), finder fees |
| **Banking & Merchant Fees** | account fees, wire/e-transfer fees, FX spreads, Stripe/card processing fees |
| **Professional Services** | accountant, lawyer (ILA referrals NBV absorbs, agreement drafting), bookkeeper |
| **Licenses & Memberships** | CICC licence & annual fees, E&O insurance, CPD courses, professional memberships |
| **Software & Subscriptions** | CRM hosting, e-signature, research tools, Microsoft/Google, phone/VoIP |
| **Office & Rent** | rent, utilities, internet, office supplies, equipment |
| **Salaries & Contractors** | staff payroll (summary-level), plan-writer contractors, VA services |
| **Travel & Client Development** | business travel, client meetings, meals & entertainment (50% ITC rule flagged) |
| **Telecom & Communications** | phone plans, WhatsApp Business API, SMS gateway |
| **Insurance** | E&O top-ups, office, cyber |
| **Training & Development** | courses, conferences, certifications |
| **Government & Compliance (NBV's own)** | NBV corporate registry fees, business licences |
| **Miscellaneous** | anything else — monthly review forces re-classification |

#### Simple, automated capture (the "seconds, not minutes" workflow)
1. **📧 Email-in receipts:** forward any receipt/bill to `expenses@nbv...` → OCR extracts
   vendor, date, amount, GST/HST → auto-suggests category from vendor rules → lands in an
   **Expense Inbox** for one-click confirm. Receipt image auto-attached.
2. **📱 Snap & upload:** drag-drop or phone photo into the Expense Inbox — same OCR flow.
3. **🔁 Recurring expenses:** rent, software subscriptions, insurance, CICC fees set once
   (amount, frequency, category) → auto-posted monthly/annually; variance alert if a
   recurring bill arrives at a different amount than expected.
4. **🤖 Vendor rules:** "RBC = Banking Fees", "Google Ads = Marketing" — after the first
   categorization the system remembers; 80%+ of expenses auto-categorize over time.
5. **🏦 Bank-feed matching:** the monthly bank-to-CRM matching report (M8.5) now also covers
   the operating account's **outflows** — any bank debit without a recorded expense is
   flagged "missing receipt" (and vice versa). CSV bank-statement import in Phase 1;
   live bank feeds (Plaid/Flinks) in Phase 2.
6. **Approval (light):** expenses under a threshold (e.g., $200) auto-approve; above it →
   Admin/Owner approval queue. Staff can submit reimbursable expenses (mileage rate built in).

#### Tracking & reporting
- Each expense: vendor, date, amount, **GST/HST ITC portion** (auto-split; meals auto-flag
  50%), category, payment method/account, receipt attached, optional link to a client/case
  (e.g., courier for a specific file → can be flagged billable → pushed to that client's
  invoice as a disbursement) or to a campaign (e.g., "Nigeria webinar Q2").
- **Budgets per category** (monthly/annual) with burn-rate alerts at 80%/100%.
- **Marketing ROI view:** campaign expense vs leads generated vs clients won vs fees
  collected (links to Lead.source) — e.g., "Nigeria webinar: $2,400 spent → 9 leads →
  2 clients → $51,000 fees".
- Dashboards: expenses by category by month, fixed vs variable, expense-to-revenue ratio,
  vendor top-10, missing-receipt count (target zero).
- **Feeds automatically into:** CRA Year-End Package (expense register + ITC summary by
  category, GIFI-mapped for the T2), per-client profitability (client-linked expenses), and
  firm P&L (revenue M8.5 − expenses M8.6 = true net income view).

### M10 — Industry-standard capability checklist (gap closure roadmap)
Benchmarked against Officio/CaseEasy/Clio. ✔ = already in this spec; ➕ = added below; Ph2/3 = phased.

| Capability | Status |
|---|---|
| Lead pipeline, intake, conversion analytics | ✔ |
| Quote/fee negotiation with approval workflow | ✔ (ahead of most competitors) |
| Case stages, deadlines, auto-tasks, compliance gates | ✔ |
| Document repository: taxonomy, versioning, retention | ✔ |
| Trust accounting + reconciliation (CICC) | ✔ |
| Per-client profitability + year-end tax pack | ✔ (M8.5) |
| Internal operating-expense tracking w/ OCR inbox, budgets, marketing ROI | ✔ (M8.6) |
| ➕ **Referral agent management** — overseas agents/sub-agents per lead: agreements on file, commission schedule (flat/% of collected fees), commission ledger (earned only when client pays), payout tracking, agent performance ranking. Industry-critical for C11 client acquisition | **Phase 1** |
| ➕ **Template & merge document generation** — retainers, quotes, invoices, submission letters, closing letters generated from templates with merge fields; consistent branding | **Phase 1** |
| ➕ **Intake questionnaires/web forms** — branded online forms (lead capture, entrepreneur profile, doc-collection requests) feeding directly into the CRM; no re-typing | **Phase 1** |
| ➕ **Time tracking (lightweight)** — optional timers per case for true cost/profitability and CICC "time entries and logs" record-keeping | Phase 1 (optional) |
| ➕ **E-signature integration** (retainers, consents, quotes) — DocuSign/Documenso | Phase 2 |
| ➕ **Email 2-way sync** (Gmail/Outlook) + shared inbox per case; WhatsApp Business logging | Phase 2 |
| ➕ **Client portal** — secure doc upload, status view, invoice payment | Phase 2 |
| ➕ **Online payments** — Stripe payment links on invoices; auto payment-reminder sequences | Phase 2 |
| ➕ **Accounting sync** — QuickBooks/Xero 2-way | Phase 2 |
| ➕ **IRCC processing-times feed** on case screens; status-check reminders | Phase 2 |
| ➕ **KPI/BI dashboards** — conversion, cycle times per stage, approval rates by sector/officer trends, agent ROI, discount effectiveness | Phase 2 |
| ➕ **Client satisfaction surveys** (post-milestone NPS) + Google-review request automation | Phase 3 |
| ➕ IRCC form auto-fill | Phase 3 |

As v1 (auto task bundles per stage, deadline engine, templates, audit pack export), with
C11-specific dashboard widgets: proposals by state, incorporations in progress, bank accounts
pending, A-numbers awaited, **WP expiry countdown board**, extension pipeline.

---

## 5. Non-functional requirements — unchanged from v1
(Canada-hosted PIPEDA data residency, AES-256 + field-level encryption for passports/UCI/bank
details, MFA, append-only audit log, 6-year retention with destruction dates, daily backups.)

## 6. Out of scope now: client portal (Ph2), IRCC form autofill (Ph3), accounting GL (export to QuickBooks).

## 7. Success criteria (90 days)
- Every active client shows linked **Proposal + Corporation + Bank + WP case** on one screen.
- Zero missed deadlines (A-number gates, biometrics, ADR, WP expiries all tracked).
- Business plan version history complete for 100% of submissions (as-filed PDF locked+hashed).
- Monthly trust reconciliation < 30 min; any client audit pack exportable < 5 min.
