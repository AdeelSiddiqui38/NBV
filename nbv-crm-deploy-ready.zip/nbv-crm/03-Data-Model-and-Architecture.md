# NBV CRM — Data Model & Technical Architecture

## 1. Recommended Stack (small firm, Canada-hosted, low ops burden)

| Layer | Choice | Why |
|---|---|---|
| Frontend | **Next.js 14 (App Router) + TypeScript + Tailwind + shadcn/ui** | Fast to build, hire-able skill set |
| Backend | Next.js API routes / server actions (monolith) | One deployable; right-sized for a small team |
| Database | **PostgreSQL** (Neon / RDS / Supabase — **ca-central-1 / Canada region**) | Relational fits cases+ledger; PIPEDA residency |
| ORM | Prisma | Schema-as-code, migrations |
| Auth | NextAuth/Auth.js + TOTP MFA (or Clerk/Auth0 with Canada residency review) | Staff-only, role claims |
| File storage | S3-compatible bucket in Canada (private, presigned URLs), SHA-256 hash on upload | Document vault |
| PDF generation | react-pdf / Puppeteer templates | Invoices, receipts, audit packs |
| Email | Resend/SES + template engine; BCC-dropbox inbound (Phase 1) | Comms logging |
| Background jobs | Vercel cron / small worker (BullMQ) | Deadline & expiry scans nightly |
| Hosting | Vercel + Canadian DB/storage, or fully on AWS ca-central-1 | Simplicity vs full residency |
| Audit log | Append-only `activity_log` table + DB trigger on sensitive tables | CICC evidence |

**Build vs buy note:** Officio/CaseEasy cost roughly $25–$100+/user/month. Custom build makes
sense if you want NBV-specific workflows, data ownership, and no per-seat fees — but budget
8–12 weeks of development for Phase 1. The included prototype lets you validate first.

---

## 2. Entity-Relationship Overview (C11-centred)

```
User ─┬────────────────────────────────────────────────────────────┐
      │ (RCIC / case manager / plan writer roles)                  │
      ▼                                                            ▼
Lead ──converted──► Client ◄──family_link──► Client          ActivityLog (append-only,
 (C11 scorecard)      │                                       polymorphic, before/after
                      │ 1:N                                   JSON, timestamps)
                      ▼
                    Case (C11_NEW | C11_PURCHASE | C11_EXT | SPOUSE_OWP | PR_TRANSITION...)
                      ├── 1:1 ► BusinessProposal ── 1:N ► ProposalVersion (state machine,
                      │           ├ FinancialProjection (yr, revenue, expenses, cashflow)
                      │           └ PlannedHire (title, NOC/TEER, salary, FTE, startQuarter)
                      ├── 1:1 ► CorporateEntity
                      │           ├ Shareholder[] (≥51% validator)
                      │           ├ CorpRegistration (BN, RC/RP/RT accounts, jurisdiction)
                      │           ├ ComplianceDate[] (annual return, tax year-end, GST)
                      │           └ 1:N ► BankAccount ── 1:N ► CapitalTransaction
                      │                                  (client business funds — informational,
                      │                                   NOT NBV trust; source-of-funds links)
                      ├── 1:1 ► EmployerPortalRecord (offerSubmittedAt, complianceFeePaid,
                      │                                aNumber ⛔ gate, jobTitle, noc, teer, salary)
                      ├── 1:1 ► WorkPermitRecord (submittedAt, appNumber, biometrics, medical,
                      │                            decision, permitStart/End → 18-mo cap countdown)
                      ├── 1:N ► ActualHire (maps to PlannedHire — extension evidence)
                      ├── 1:N ► DocumentItem ► FileVersion (sha256, versioned)
                      ├── 1:N ► Task / Deadline / Appointment / CaseStageLog
                      ├── 1:N ► Invoice ► InvoiceLine / Payment
                      └── 1:1 ► RetainerAgreement
Client 1:N ──► TrustTransaction (NBV client account — CICC ledger, separate module)
Client 1:N ──► ClientPropertyItem / ContactLogEntry (advice-flagged, lockable)
CaseType 1:N ──► StageTemplate / ChecklistTemplate / DeadlineRule / SectorTemplate
```

## 3. Core Tables (abridged Prisma-style)

```prisma
model User {
  id            String @id @default(cuid())
  email         String @unique                 // login ID
  name          String
  role          Role                           // ADMIN | RCIC | CASE_MANAGER | PLAN_WRITER | ACCOUNTANT
  rcicLicenseNo String?                        // shown on retainers/submissions for RCIC role
  passwordHash  String                         // argon2id — never retrievable
  mfaSecret     String?                        // TOTP; mandatory for ADMIN/RCIC
  mfaEnabled    Boolean @default(false)
  status        UserStatus @default(INVITED)   // INVITED | ACTIVE | DEACTIVATED
  invitedById   String?
  lastLoginAt   DateTime?
  failedAttempts Int @default(0)               // lockout after 5
  lockedUntil   DateTime?
  internalRate  Decimal?                       // for time-cost in profitability
  sessions      Session[]
  createdAt     DateTime @default(now())
  deactivatedAt DateTime?                      // history preserved forever — no hard deletes
}

model Session {
  id          String @id @default(cuid())
  userId      String
  device      String                           // UA summary: "Chrome · Windows · Calgary"
  ip          String
  createdAt   DateTime @default(now())
  lastSeenAt  DateTime
  revokedAt   DateTime?                        // remote sign-out
}

model LoginEvent {                             // append-only login audit
  id        BigInt @id @default(autoincrement())
  email     String
  userId    String?
  success   Boolean
  ip        String
  device    String
  newDevice Boolean @default(false)            // triggers email alert
  at        DateTime @default(now())
}

// Auth flows: invite email → user sets own password (min 12 chars, breached-list check,
// no reuse of last 5) + MFA enrolment on first login. Password reset = time-limited
// single-use email link; Admin can force-reset but never view. Sessions: 30-min idle
// timeout (configurable), concurrent-session list with remote revoke, throttled attempts.
// Deactivation: sessions revoked instantly + guided reassignment wizard for open
// tasks/cases; user history retained on all records (CICC accountability).
// Phase 2/3: SSO (Google/Microsoft), IP allow-list per role, passkeys/WebAuthn.

model Client {
  id              String   @id @default(cuid())
  clientNumber    String   @unique            // NBV-C-2026-0001
  firstName       String
  lastName        String
  email           String?
  phone           String?
  dateOfBirth     DateTime?
  countryOfResidence String?
  maritalStatus   MaritalStatus?
  uciNumber       String?                     // encrypted
  passportNumber  String?                     // encrypted
  passportExpiry  DateTime?
  bankDetailsEnc  String?                     // AES field-level encrypted JSON (refunds)
  pipedaConsentAt DateTime?
  source          String?
  status          ClientStatus @default(ACTIVE) // ACTIVE | INACTIVE | ARCHIVED
  familyLinks     FamilyLink[] @relation("from")
  cases           CaseParty[]
  trustTxns       TrustTransaction[]
  createdAt       DateTime @default(now())
}

model FamilyMember {                           // household captured once, reused everywhere
  id            String @id @default(cuid())
  clientId      String                         // principal applicant's client record
  relationship  Relationship                   // SPOUSE | COMMON_LAW | CHILD | PARENT | OTHER
  accompanying  Boolean @default(true)         // drives checklists, fees, LICO, medicals
  firstName     String
  lastName      String
  nativeScriptName String?
  dateOfBirth   DateTime
  birthPlace    String?
  citizenships  String[]
  passportNoEnc String?                        // encrypted
  passportExpiry DateTime?                     // feeds expiry radar
  maritalStatus String?
  occupationOrGrade String?                    // job / school grade
  priorCanadaStatus String?
  priorRefusals Boolean @default(false)
  refusalNotes  String?
  uci           String?
  dependentEligible Boolean?                   // auto: <22 & unmarried, or 22+ dependent condition
  age22LockDate DateTime?                      // alert before a child ages out
  relationshipEvidenceDocIds String[]          // marriage/birth/custody docs (folder 02)
  memberChecklist DocumentItem[]               // per-member docs: passport, photos, PCC, medical...
  biometricsStatus String?                     // REQUIRED|BOOKED|DONE|EXEMPT (ages 14–79)
  medicalStatus    String?                     // REQUIRED|BOOKED|PASSED|N/A + eMedical #
  companionCaseId  String?                     // linked Spouse OWP / child SP / visitor case
}

// Family-driven automation:
//  • LICO line in dual-funding checklist = f(1 + accompanying members), recalc on change
//  • Spouse OWP eligibility = principal's offer TEER in (0,1) → one-click companion case
//  • Child: school-age → Study Permit companion + enrolment-evidence task; else visitor record
//  • Family fees calculator: WP $155 + OWP $255 + SP $150/child + biometrics ($85 / $170 family cap)
//  • IMM 5707/5645 prefilled from FamilyMember rows; cross-case consistency checker
//    (addresses/dates/names compared across all linked family applications)
//  • Post-approval task bundle: landing plan, SINs, health cards, school registration

model Case {
  id              String   @id @default(cuid())
  fileNumber      String   @unique            // NBV-2026-0001
  caseTypeId      String                      // EE_FSW, PNP_AB_EXPRESS, SPOUSAL_OUTLAND...
  currentStage    String
  rcicId          String                      // responsible licensee
  caseManagerId   String?
  status          CaseStatus @default(OPEN)   // OPEN | ON_HOLD | CLOSED | WITHDRAWN
  openedAt        DateTime                    // = retainer signing date (CICC 5.1)
  closedAt        DateTime?
  destructionDate DateTime?                   // closedAt + 6 years
  keyDates        Json                        // {itaDate, eaprDeadline, aorDate, ...}
  parties         CaseParty[]
  documents       DocumentItem[]
  deadlines       Deadline[]
  invoices        Invoice[]
  retainer        RetainerAgreement?
}

model FeeQuote {                               // pre-onboarding fee negotiation (list $30,000)
  id            String @id @default(cuid())
  leadId        String
  caseId        String?                        // linked after conversion
  version       Int    @default(1)             // counter-offers = new versions, full history
  listPrice     Decimal                        // snapshot of fee schedule at quote time
  feeScheduleId String                         // versioned price book
  adjustments   QuoteAdjustment[]              // each with type + reason + author
  agreedFee     Decimal?                       // computed: list − adjustments
  currency      String @default("CAD")
  status        QuoteStatus @default(DRAFT)    // DRAFT|PENDING_APPROVAL|SENT|NEGOTIATING|AGREED|DECLINED|EXPIRED
  requiresApproval Boolean @default(false)     // out-of-authority discount
  approvedById  String?                        // Admin/Owner when below authority/floor
  sentAt        DateTime?
  expiresAt     DateTime?                      // default +30 days
  agreedAt      DateTime?
  acceptanceRef String?                        // email/signature evidence doc link
  milestonePlanId String?                      // % split template applied to agreedFee
}

model QuoteAdjustment {
  id        String @id @default(cuid())
  quoteId   String
  type      AdjType                            // PCT_DISCOUNT|FIXED_REDUCTION|SCOPE_REMOVED|MARKET_ADJ|EQUITY_CONSIDERATION|PLAN_PREMIUM
  amount    Decimal                            // negative = reduction
  reason    String                             // mandatory, reportable
  createdById String
}

// Settings: FeeSchedule (versioned list price + component breakdown + floorPrice)
//           DiscountAuthority (role → max % / floor; beyond → PENDING_APPROVAL)
// Gate: Lead→Client conversion and retainer generation REQUIRE quote.status == AGREED;
//       retainer fee, milestone amounts, and invoices derive from agreedFee (no free-typing).
// Post-retainer fee changes create a RetainerAddendum (RCIC approval + client consent + reason).

model BusinessProposal {
  id            String @id @default(cuid())
  caseId        String @unique
  sector        String                        // NAICS + sector template key
  locationCity  String
  locationProv  String
  benefitAngles String[]                      // jobs | regional | innovation | supply_chain
  state         ProposalState @default(OUTLINE) // OUTLINE|DRAFTING|INTERNAL_REVIEW|CLIENT_REVIEW|CLIENT_APPROVED|FINAL_LOCKED|SUBMITTED
  rcicSignedOffAt   DateTime?
  clientApprovedAt  DateTime?
  finalSha256   String?                       // locked as-submitted PDF hash
  versions      ProposalVersion[]
  projections   FinancialProjection[]         // 3-yr P&L/cashflow rows as data
  plannedHires  PlannedHire[]                 // title, noc, teer, salary, fte, startQuarter
}

model CorporateEntity {
  id            String @id @default(cuid())
  caseId        String @unique
  legalName     String?
  jurisdiction  String                        // CBCA | AB | BC | ON | SK ...
  nuansRef      String?
  articlesFiledAt DateTime?
  certificateNo String?
  incorporatedAt DateTime?
  businessNumber String?                      // CRA BN
  craAccounts   String[]                      // RC0001, RP0001, RT0001
  registeredOffice String?
  stage         IncStage @default(NAME_SEARCH) // NAME_SEARCH|ARTICLES_FILED|INCORPORATED|BN_OBTAINED|MINUTE_BOOK_DONE|COMPLETE
  shareholders  Shareholder[]                 // % check: client must hold >= 51
  complianceDates ComplianceDate[]            // annual return, tax year-end, GST freq
  bankAccounts  BankAccount[]
}

model BankAccount {
  id            String @id @default(cuid())
  corpId        String
  bankName      String
  status        BankStatus @default(SELECTED) // SELECTED|APPT_BOOKED|DOCS_SUBMITTED|OPENED|CAPITAL_DEPOSITED|VERIFIED
  openedAt      DateTime?
  accountMasked String?                       // last 4 only; full details never stored
  capitalTxns   CapitalTransaction[]          // client business funds — informational ledger
}

model CapitalTransaction {                     // NOT NBV trust — client's own business capital
  id          String @id @default(cuid())
  bankAccountId String
  date        DateTime
  amountCad   Decimal
  fxNote      String?                         // original currency/rate/wire ref
  source      String                          // savings | property sale | gift | loan ...
  sourceDocId String?                         // link to source-of-funds DocumentItem
}

// Every Case carries:  engagementMode  EngagementMode  @default(SOLE_OWNERSHIP)
//   SOLE_OWNERSHIP        → client 100%, pays all costs, no PartnershipDeal allowed
//   PARTNERSHIP_FINANCIAL → NBV equity + cost sharing (deal.financialInvolvement = true)
//   PARTNERSHIP_SERVICES  → NBV equity, $0 NBV money ("sweat equity", financialInvolvement = false)
// Mode changes require RCIC approval + logged reason + retainer addendum.

model PartnershipDeal {                        // NBV equity stake in client corp (e.g., 30% / 40%)
  id              String @id @default(cuid())
  corpId          String @unique
  financialInvolvement Boolean                 // true = mode B (cost sharing), false = mode C (sweat equity)
  clientPct       Decimal                      // must stay >= 51 (C11)
  nbvPct          Decimal                      // capped <= 49 by validator
  otherPct        Decimal @default(0)
  feeArrangement  String                       // FULL_FEES | REDUCED_FEES | FEES_FOR_EQUITY
  servicesConsiderationDocId String?           // required for mode C before SHARES_ISSUED
  costSplits      CostSplit[]                  // mode B only
  interPartyTxns  InterPartyTxn[]              // mode B: who paid what, settlements
  status          DealStatus @default(STRUCTURING) // STRUCTURING|COI_GATE|AGREEMENTS|SHARES_ISSUED|ACTIVE|EXITED
  // CICC conflict-of-interest gate — all required before SHARES_ISSUED:
  coiDisclosureDocId String?                   // written disclosure of NBV interest
  ilaStatus       IlaStatus?                   // CONFIRMED | WAIVED_IN_WRITING
  ilaDocId        String?
  clientConsentDocId String?
  retainerAddendumDocId String?
  // agreements & economics:
  shareholderAgreementDocId String?
  boardSeat       Boolean @default(false)
  nbvCapitalCommitted Decimal @default(0)
  nbvCapitalPaid  Decimal @default(0)          // traced in CapitalTransaction (party=NBV)
  distributions   Distribution[]               // date, totalDeclared, nbvShare, clientShare, evidence
  valuationNotes  ValuationNote[]
  exitedAt        DateTime?
  exitType        String?                      // BUYBACK | SALE | DILUTION | WIND_DOWN
  exitProceeds    Decimal?
}

model CostSplit {                              // mode B: per-category cost sharing
  id          String @id @default(cuid())
  dealId      String
  category    CostCategory                     // INCORPORATION | GOVT_FEES | BUSINESS_CAPITAL | OPERATING_TOPUP | OTHER
  clientPct   Decimal                          // e.g., 70
  nbvPct      Decimal                          // e.g., 30 (default pro-rata to equity, overridable)
}

model InterPartyTxn {                          // mode B: actual payments vs owed shares
  id          String @id @default(cuid())
  dealId      String
  date        DateTime
  category    CostCategory
  description String                           // "AB incorporation fee $525"
  totalAmount Decimal
  paidBy      Party                            // CLIENT | NBV
  clientShare Decimal                          // computed from CostSplit
  nbvShare    Decimal
  settled     Boolean @default(false)          // running inter-party balance derived from unsettled rows
  settlementRef String?
}

model Distribution {
  id          String @id @default(cuid())
  dealId      String
  declaredAt  DateTime
  totalAmount Decimal
  nbvShare    Decimal
  clientShare Decimal
  paidAt      DateTime?
  evidenceDocId String?
}

// CapitalTransaction gains: party  ContributorParty  // CLIENT | NBV | OTHER
//   → keeps the client's own-funds evidence for IRCC separable from NBV's contribution.

model EmployerPortalRecord {
  id              String @id @default(cuid())
  caseId          String @unique
  enrolledAt      DateTime?
  jobTitle        String?
  noc             String?
  teer            Int?                        // drives spouse-OWP eligibility flag (TEER 0/1)
  salary          Decimal?
  offerSubmittedAt DateTime?
  complianceFeePaidAt DateTime?               // $230
  aNumber         String?                     // ⛔ WP submission gate requires this
}

model WorkPermitRecord {
  id            String @id @default(cuid())
  caseId        String @unique
  submittedAt   DateTime?
  applicationNo String?
  biometricsDoneAt DateTime?
  medicalPassedAt  DateTime?
  decision      WpDecision?                   // APPROVED | REFUSED | WITHDRAWN
  decisionAt    DateTime?
  permitStart   DateTime?
  permitEnd     DateTime?                     // 18-month cap; drives T-180/120/60 alerts
  refusalReasons String?
}

model Folder {                                 // standard taxonomy, auto-created per case
  id          String  @id @default(cuid())
  caseId      String?                          // null = client-level shared folder
  clientId    String?
  code        String                           // "05" — ordering + template key
  name        String                           // "Corporate Records"
  systemFolder Boolean @default(true)          // cannot delete while case open
  roleAccess  Json                             // {planWriter:false, accountant:false, ...}
  documents   DocumentItem[]
}

model DocumentItem {
  id          String  @id @default(cuid())
  caseId      String?
  folderId    String                           // every document lives in exactly one folder
  checklistItemId String?                      // checklist-driven intake mapping
  docType     String                           // controlled list: PASSPORT, POLICE_CERT, ARTICLES, ...
  party       Party                            // CLIENT|SPOUSE|CORP|NBV
  name        String                           // enforced: YYYY-MM-DD_<DocType>_<Party>_v<N>
  required    Boolean @default(true)
  status      DocStatus @default(REQUESTED)    // REQUESTED|RECEIVED|UNDER_REVIEW|APPROVED|SUBMITTED|EXPIRED|SUPERSEDED
  issueDate   DateTime?
  expiryDate  DateTime?                        // feeds 90/60/30-day expiry radar
  language    String?
  translated  Boolean @default(false)
  isOriginal  Boolean @default(false)          // true → auto-entry in ClientPropertyItem (CICC s.5.3)
  locked      Boolean @default(false)          // FINAL plan, signed retainer, advice letters
  reviewedById String?
  unfiled     Boolean @default(false)          // triage queue (email-dropbox/scan intake)
  versions    FileVersion[]                    // storageKey, sha256, size, virus-scan result, uploadedBy, ts
}

model AsFiledSnapshot {                        // frozen "what went to IRCC on date X"
  id          String @id @default(cuid())
  caseId      String
  label       String                           // "eAPR submission Jun 19 2026" / "ADR response"
  createdAt   DateTime
  createdById String
  items       Json                             // [{documentId, versionId, sha256}]
  indexPdfKey String                           // generated index with hashes
}

model Invoice {
  id          String @id @default(cuid())
  number      String @unique                 // NBV-INV-2026-0001
  caseId      String?
  clientId    String
  status      InvoiceStatus @default(DRAFT)
  issueDate   DateTime
  dueDate     DateTime
  currency    String @default("CAD")
  subtotal    Decimal
  taxRate     Decimal                        // GST/HST by province
  total       Decimal
  lines       InvoiceLine[]                  // professional fees vs disbursements flagged
  payments    Payment[]
}

model TrustTransaction {                      // CICC client-account ledger
  id          String @id @default(cuid())
  clientId    String
  caseId      String?
  type        TrustTxnType                   // DEPOSIT | TRANSFER_TO_OPERATING | DISBURSEMENT | REFUND
  amount      Decimal
  date        DateTime
  method      String?
  reference   String?
  invoiceId   String?                        // earning event linkage
  enteredById String
  approvedById String?                       // RCIC approval gate
  memo        String
}

model NbvBankAccount {                         // NBV's own accounts (operating, trust) — Settings
  id        String @id @default(cuid())
  label     String                             // "RBC Operating", "RBC Trust (Client Account)"
  type      NbvAcctType                        // OPERATING | TRUST
  maskedNo  String
}
// Payment & TrustTransaction gain: nbvBankAccountId + bankRef (e-transfer/wire id)
// → monthly bank-to-CRM matching report; unmatched deposits flagged.

model ClientPnlSnapshot {                      // materialized per-client profitability (nightly)
  id            String @id @default(cuid())
  clientId      String
  period        String                         // YYYY-MM
  feesInvoiced  Decimal
  feesCollected Decimal
  equityIncome  Decimal                        // distributions received (Modes B/C)
  realizedGains Decimal                        // exits: proceeds − ACB (NBV capital in)
  consultFees   Decimal
  staffTimeCost Decimal                        // from TimeEntry at internal rates (optional)
  costSplitOutlay Decimal                      // Mode B NBV-paid shares
  commissionsPaid Decimal                      // referral agents
  disbAbsorbed  Decimal
  refunds       Decimal
  margin        Decimal                        // computed
}

model TimeEntry {                              // lightweight; also CICC "time entries and logs"
  id        String @id @default(cuid())
  caseId    String
  userId    String
  minutes   Int
  activity  String
  date      DateTime
  internalRate Decimal                         // snapshot of user's cost rate
}

model ReferralAgent {
  id          String @id @default(cuid())
  name        String
  country     String
  agreementDocId String?
  commissionType CommType                      // FLAT | PCT_OF_COLLECTED
  commissionValue Decimal
  leads       Lead[]
  commissions CommissionEntry[]
}

model CommissionEntry {                        // earned only when client payment collected
  id        String @id @default(cuid())
  agentId   String
  caseId    String
  paymentId String                             // trigger: collected payment
  amount    Decimal
  status    CommStatus @default(ACCRUED)       // ACCRUED | APPROVED | PAID
  paidAt    DateTime?
  payoutRef String?
}

model ExpenseCategory {                        // chart of expense headers — Settings, GIFI-mapped
  id        String @id @default(cuid())
  name      String                             // "Marketing & Advertising", "Banking & Merchant Fees"...
  gifiCode  String?
  monthlyBudget Decimal?                       // burn-rate alerts at 80%/100%
  itcRule   ItcRule @default(FULL)             // FULL | MEALS_50 | NONE
  vendorRules VendorRule[]
}

model VendorRule {                             // "RBC → Banking Fees" auto-categorization
  id          String @id @default(cuid())
  categoryId  String
  vendorMatch String                           // normalized vendor name / pattern
}

model Expense {
  id          String @id @default(cuid())
  categoryId  String
  vendor      String
  date        DateTime
  amount      Decimal
  gstHstItc   Decimal                          // auto-split per category itcRule
  method      String?                          // card | e-transfer | account debit
  nbvBankAccountId String?
  receiptDocId String?                         // OCR'd receipt image/PDF
  status      ExpStatus @default(INBOX)        // INBOX | CONFIRMED | PENDING_APPROVAL | APPROVED | REIMBURSED
  source      ExpSource @default(MANUAL)       // EMAIL_IN | UPLOAD | RECURRING | BANK_IMPORT | COMMISSION_FEED
  recurringId String?
  caseId      String?                          // optional client link
  billable    Boolean @default(false)          // → pushed to client invoice as disbursement
  campaign    String?                          // marketing ROI link to Lead.source
  submittedById String?                        // staff reimbursables (mileage rate supported)
  approvedById  String?                        // required above threshold (Settings)
}

model RecurringExpense {                       // rent, subscriptions, insurance, CICC fees
  id          String @id @default(cuid())
  categoryId  String
  vendor      String
  amount      Decimal
  frequency   Freq                             // MONTHLY | QUARTERLY | ANNUAL
  nextPostAt  DateTime
  varianceAlertPct Decimal @default(10)        // bill differs from expected → alert
}

// Automation: expenses@ inbox → OCR (vendor/date/amount/tax) → vendor-rule category suggestion
//             → Expense Inbox one-click confirm. Bank CSV import matches debits ↔ expenses;
//             unmatched debits flagged "missing receipt". Commission payouts auto-create
//             expenses under Referral & Commissions. Feeds: Year-End Package (expense register
//             + ITC summary, GIFI), firm P&L, per-client profitability (case-linked), and
//             Marketing ROI (campaign → leads → clients → fees).

model GlMapping {                              // Settings: service line → GL/GIFI category
  id          String @id @default(cuid())
  serviceLine String                           // C11_FEES | PLAN_FEES | INCORP_FEES | CONSULT | EQUITY_INCOME...
  glCode      String
  gifiCode    String?
}
// Year-End Package job: invoice register, payments register, GST/HST collected + ITC summary,
// equity income schedule (T5 expected-vs-received per deal, ACB per deal), unearned trust
// liability at year-end, disbursement + commission registers → PDF + CSV + QBO/Xero import.

model ActivityLog {                           // append-only; no UPDATE/DELETE grants
  id         BigInt   @id @default(autoincrement())
  actorId    String
  entityType String
  entityId   String
  action     String                          // created|updated|stage_changed|viewed_sensitive|...
  diff       Json?
  createdAt  DateTime @default(now())
}
```

(Full schema would also include: Lead, FamilyLink, CaseParty, StageTemplate, ChecklistTemplate,
DeadlineRule, Task, Appointment, ContactLogEntry, ClientPropertyItem, RetainerAgreement,
EmailTemplate, User/Role, Setting.)

## 4. Key Mechanics (C11 additions first)

- **Employer Portal gate:** stage transition to "WP Submitted" is blocked server-side unless
  `EmployerPortalRecord.aNumber` exists and compliance fee date is set.
- **51% validator:** saving a Shareholder table where the client's total < 51% raises a blocking
  warning (override only by RCIC with logged reason). With a PartnershipDeal attached, the same
  validator also enforces **NBV ≤ 49%** and `clientPct + nbvPct + otherPct = 100`.
- **Conflict-of-interest gate:** `PartnershipDeal.status` cannot advance to SHARES_ISSUED unless
  disclosure doc + ILA (confirmed or written waiver) + client consent + retainer addendum are all
  on file — enforced server-side, every step timestamped on the locked timeline.
- **Capital party-tagging:** every CapitalTransaction is tagged CLIENT / NBV / OTHER so the
  IRCC evidence pack shows the client's own investment cleanly, and NBV's equity book is
  computed from its own tagged contributions.
- **Engagement-mode enforcement:**
  - SOLE_OWNERSHIP → creating a PartnershipDeal is blocked; share validator expects client 100%.
  - PARTNERSHIP_SERVICES (mode C) → NBV-tagged CapitalTransactions are rejected with a
    mismatch warning; `servicesConsiderationDocId` required before SHARES_ISSUED.
  - PARTNERSHIP_FINANCIAL (mode B) → posting a shared-category disbursement without a defined
    CostSplit is blocked; each payment generates an InterPartyTxn computing both shares; the
    inter-party balance widget shows "NBV owes client / client owes NBV" until settled.
- **Dual-funding readiness meter:** computed flag = (corp bank status ≥ CAPITAL_DEPOSITED AND
  business-capital docs approved) AND (personal LICO funds docs approved) — shown on the case
  header and required for the WP-prep gate.
- **18-month cap countdown:** nightly job creates alerts at permitEnd − 180/120/60 days and
  auto-opens an "Extension strategy" task at T-180.
- **PlannedHire vs ActualHire report:** one click produces the job-creation comparison table —
  the core exhibit for C11 extensions.
- **Proposal locking:** moving a proposal to FINAL_LOCKED stores the PDF, computes SHA-256, and
  freezes all versions (further edits require a new version branch, fully logged).
- **Repository rules:** every document must belong to a folder (taxonomy auto-created from the
  case-type template); uploads without complete metadata stay in the Unfiled queue and count on
  the dashboard; deletes are soft-only and blocked entirely on locked docs and closed files;
  storage keys are non-guessable UUIDs served via short-lived presigned URLs; folder roleAccess
  is enforced server-side per request; case closing flips the whole repository read-only and
  schedules the +6-year destruction-approval workflow.

- **Deadline engine:** nightly job scans `Deadline` + document expiries + stage SLA rules →
  creates dashboard alerts and assignee tasks at T-90/60/30/7/1 days as configured per rule.
- **Stage transitions:** API validates allowed transitions per CaseType template; transitions
  with `requiresRcicApproval=true` (e.g., → "eAPR Submitted") need an approval record first;
  each transition spawns that stage's task bundle and deadline clocks.
- **Trust integrity:** trust balance per client can never go negative (DB constraint);
  TRANSFER_TO_OPERATING must reference an issued invoice; monthly reconciliation report =
  Σ client balances vs entered bank statement balance, variances flagged.
- **Sensitive field reads:** decrypting passport/UCI/bank fields writes a `viewed_sensitive`
  activity log entry with actor + timestamp.
- **Audit pack export:** ZIP = case summary PDF + timeline PDF + documents index + all files
  + financial statement; generated server-side, download logged.

## 5. Phased Roadmap

| Phase | Duration | Scope |
|---|---|---|
| **0 — Prototype (done)** | — | Clickable single-file prototype (in this workspace) to validate flows |
| **1 — MVP** | 6–8 wks | Auth+MFA, Leads, Clients, Cases (3 program families), Documents, Tasks/Calendar, Invoices+Payments, Trust ledger, Dashboard, Audit log |
| **2 — Efficiency** | +4–6 wks | Client portal, Stripe payments, Gmail/Outlook sync, e-signature, booking page, automations builder |
| **3 — Scale** | later | IRCC form auto-fill, reporting suite, QuickBooks sync, WhatsApp Business API logging |
```
