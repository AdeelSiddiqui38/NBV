# NBV Immigration CRM — Project Package (v2 — C11-focused)

**Client:** Next Bridge Ventures (nextbridgeventures.ca)
**Scope confirmed:** Spec/blueprint first · all modules · staff-only · **core business = C11 entrepreneur work permits**, where NBV prepares a business proposal, incorporates a new company, and opens a corporate bank account for each client.

| File | What it is |
|---|---|
| `01-Product-Requirements.md` | Full PRD v2.4: C11-centred modules incl. **Fee Quotation & Negotiation (list CAD $30,000, negotiable — Agreed-quote gate before onboarding, discount authority matrix)**, **Business Proposal workspace**, **Corporate Entity register**, **Banking & Capital tracker**, the **Engagement Structure selector** (A sole 100% / B partnership + cost split / C partnership sweat-equity), **Family Panel (household captured once → LICO auto-calc, spouse OWP / child study-permit companion cases, per-member checklists/medicals/biometrics, family fees calculator, cross-case consistency checker)**, **Secure Document Repository**, **NBV Earnings & per-client profitability + CRA Year-End package (T2/GST-HST/T5 schedules)**, **referral-agent commissions**, **NBV internal expense tracking (14 standard headers, OCR email-in inbox, recurring auto-post, bank-debit matching, budgets, marketing ROI)**, an industry-standard gap-closure roadmap, plus billing/trust, scheduling, audit, and post-May-2025 C11 rules encoded |
| `02-Process-Workflows.md` | The 13-stage C11 pipeline with parallel Tracks A (proposal) / B (incorporation) / C (bank & capital), full document checklist, business-purchase & extension variants, companion cases, CICC compliance rules |
| `03-Data-Model-and-Architecture.md` | Tech stack, C11-centred ER diagram & schema (BusinessProposal, CorporateEntity, BankAccount/CapitalTransaction, EmployerPortalRecord, WorkPermitRecord), gate/validator mechanics, build roadmap |
| `04-prototype.html` | **Clickable prototype** — Login screen (email + password + MFA), Users & Access management, Dashboard, C11 lead scorecard kanban, Cases with A·B·C track status, a full sample case file (gates, tracks, timeline, financials), Proposals, Corporations, Banks & Capital, NBV Partnerships (engagement modes A/B/C), **Secure Document Repository** (per-case folder taxonomy, unfiled triage queue, expiry radar, exports), Billing & Trust, Earnings & CRA Year-End, NBV Expenses, Audit Log |

## Next steps (suggested)
1. Click through `04-prototype.html` — especially the **Case File** screen (tracks + A-number gate) — and mark up changes.
2. Confirm NBV's actual package pricing & milestone split (prototype assumes 30/30/25/15).
3. Tell me which provinces/banks/sectors you use most so templates match reality.
4. Greenlight Phase 1 build (6–8 weeks, Next.js + PostgreSQL in Canada region) — I can scaffold the real codebase next.
