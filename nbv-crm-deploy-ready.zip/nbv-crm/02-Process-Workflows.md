# NBV CRM — C11 Process Workflows, Stage Pipeline & Checklists
**Flagship process:** C11 Work Permit — New Business (proposal → incorporation → bank → Employer Portal → WP → establishment → extension/PR)

---

## 0. Master C11 Client Lifecycle

```
INQUIRY ─► C11 PRE-QUALIFICATION ─► PAID CONSULTATION (ICA) ─► FEASIBILITY ASSESSMENT
              (scorecard: funds /                                     │
               experience / benefit /                                 ▼
               51% / temp intent)                       FEE QUOTE & NEGOTIATION
                                                        list $30,000 → adjustments
                                                        (each with reason + authority
                                                        check: RCIC ≤15%, below floor
                                                        → Owner approval) → counter-
                                                        offers logged as versions
                                                                      │
                                                        ✅ FEE AGREED (client acceptance
                                                        recorded — ⛔ gate: no retainer
                                                        without an Agreed quote)
                                                                      │
                                                                      ▼
                                                               RETAINER SENT
                                                        (agreed fee auto-populates
                                                         retainer + milestone plan)
                                                                      │
                                              ✅ RETAINER SIGNED = CLIENT / FILE OPENED (CICC 5.1)
                                              • conflict check + ID verification
                                              • IMM 5476 + intent-strategy advice (locked entry)
                                              • invoice #1 / trust deposit
                                                                      │
            ┌─────────────────────────────────────────────────────────┤
            ▼                          ▼                              ▼
   TRACK A: BUSINESS PROPOSAL   TRACK B: INCORPORATION         TRACK C: FUNDS PREP
   (drafting → reviews →        (name → articles → BN →       (source-of-funds docs,
    client approval → FINAL)     minute book)                   personal LICO funds,
            │                          │                        capital transfer plan)
            └──────────────┬───────────┴──────────────┬─────────┘
                           ▼                          ▼
                  BANK ACCOUNT OPENED        CAPITAL DEPOSITED to corp account
                           └──────────────┬───────────┘
                                          ▼
                        EMPLOYER PORTAL: offer of employment
                        + $230 compliance fee → A-NUMBER  ◄── hard gate
                                          ▼
                        WP APPLICATION ASSEMBLED → RCIC SIGN-OFF GATE → SUBMITTED
                                          ▼
                        PROCESSING (biometrics / medical / ADR / interview)
                                          ▼
                 ┌── APPROVED ──► LANDING & BUSINESS ESTABLISHMENT ──► EXTENSION or EXIT or PR
                 └── REFUSED ──► reasons analysis → reapply / JR advice (15/60-day clocks)
                                          ▼
                              FILE CLOSING (CICC s.7, +6yr retention)
```

The three tracks (A/B/C) run **in parallel** after onboarding — the CRM shows them as parallel
sub-pipelines on the case screen with a combined readiness meter for the Employer Portal gate.

---

## 1. C11 — New Business: Stage Pipeline (the system's default)

| # | Stage | Key actions & auto-task bundle | Deadlines / gates |
|---|---|---|---|
| 1 | **Onboarding** | Retainer bundle; ID + conflict check; intent-strategy advice entry (locked); entrepreneur profile (CV, prior businesses, net worth, source of funds); **Family Panel completed: all members' bio data, accompanying flags, relationship evidence → LICO line auto-set, spouse-OWP / child-SP companion plan recorded** | 7-day target |
| 2 | **Business Concept & Strategy** | Sector/location workshop; benefit-to-Canada angle defined (jobs/region/innovation); NOC/TEER of client role set (spouse OWP flag); sector template selected | RCIC strategy note required |
| 3 | **Proposal Drafting** (Track A) | Plan writer assigned; market research; 3-yr financial projections entered as data; job-creation plan (titles, salaries, quarters); drafts v0.x | Writer SLA 10–15 days |
| 4 | **Proposal Review & Approval** | Internal QA → **RCIC sign-off gate** → client review → Client Approved → FINAL locked (hash) | Client approval recorded with date/method |
| 5 | **Incorporation** (Track B) | Name options → NUANS → articles filed (jurisdiction choice logged with rationale) → certificate → minute book → **share table ≥51% validator** → CRA BN + RC/RP/RT accounts → registered office | Gate: certificate + share table valid |
| 6 | **Bank Account & Capital** (Track C) | Bank selected; appointment; account opened; **business capital deposited & traced** (capital ledger + source docs); void cheque on file; personal LICO funds evidence collected separately | Gate: dual-funding evidence complete |
| 7 | **Employer Portal & Offer** | Corp enrolled in Employer Portal; offer of employment (title/NOC/TEER/salary consistent with proposal); **$230 compliance fee**; **A-number received** | ⛔ Hard gate: no A-number → cannot advance |
| 8 | **WP Application Prep** | Forms; document set (checklist below); fees ($155 + $85 biometrics); submission letter citing R205(a) significant benefit; **RCIC final sign-off gate** | Internal review ≥5 days before filing |
| 9 | **Submitted / Processing** | Submission date + application #; biometrics (30 days from BIL); medical if required; **ADR/procedural fairness clocks** (auto-deadline from letter, 7–30 days); interview prep if convoked | ADR = hard deadlines |
| 10 | **Decision** | Approved → permit issued: record validity dates, **18-month cap countdown starts**; Refused → refusal task bundle (written advice on reasons/options/deadlines; JR 15/60 days) | |
| 11 | **Landing & Establishment** | Arrival, SIN, premises lease, business launch, **hires made vs proposal tracked**, payroll started — each logged as extension evidence | Milestone reminders quarterly |
| 12 | **Extension / Exit / PR** | T-6 mo before WP expiry: strategy meeting (extend with progress evidence + succession/exit plan, or wind down, or PNP-entrepreneur PR case opened as linked case) | T-6/T-4/T-2 auto-alerts |
| 13 | **Closing** | Final invoice; trust zeroed; property returned; closing letter; destruction date = +6 yrs | |

---

## 2. C11 Document Checklist (auto-generated per case)

**Personal/immigration:** passport; digital photo; IMM 5476; family info forms; police certificates (as required); medical (if required by country/duration); prior refusals disclosure; travel history.
**Entrepreneur credibility:** detailed CV; proof of prior business ownership/management (registrations, tax filings, org letters); educational credentials; language ability evidence (supports plausibility).
**Business Proposal pack (Track A):** FINAL business plan PDF (locked); market research annexes; financial projections; **job creation plan**; premises evidence (signed/conditional lease, LOI); supplier/vendor LOIs or contracts; client/contract pipeline letters if any.
**Corporate pack (Track B):** NUANS report; Articles of Incorporation + Certificate; share certificates & shareholder register (**≥51%**); director/officer registers; CRA BN confirmation; bylaws/organizational resolutions; extra-provincial registration if applicable.
**Financial pack (Track C):** corporate bank account confirmation + statements showing **business capital**; capital transfer trail (FX/wire receipts); **source-of-funds evidence** (sale agreements, savings history, gift deeds + donor capacity); **separate personal funds** statements meeting LICO for family size.
**Employer compliance:** offer of employment summary, **A-number**, compliance fee receipt ($230).
**Submission:** R205(a) significant-benefit submission letter (RCIC-signed); forms; fee receipts.

## 3. C11 — Business Purchase variant (delta)
Adds: target business due diligence (financial statements 2–3 yrs, tax filings, lease assignment), share/asset purchase agreement (conditional on WP ok), business valuation, vendor statutory declaration, transition/training plan, proof employees retained. Stage 5 becomes "Acquisition & Corporate Changes" (share transfer, director changes) instead of fresh incorporation when buying shares.

## 4. C11 Extension pipeline
1. Strategy review (T-6 mo) → 2. Progress evidence collection: corporate financial statements, GST/payroll filings, **hires made (T4s/paystubs) mapped against the original job-creation plan**, premises/operation photos, contracts won → 3. Updated plan + exit/succession narrative → 4. Extension filed before expiry (maintained status logged) → 5. Decision.
> The system's job-creation plan vs actual-hires comparison report is the centrepiece of extension evidence.

## 4b. Engagement Structure selection & NBV Partnership sub-flow

**At retainer signing, every case records one of three engagement structures:**

| Mode | Ownership | Costs | System behaviour |
|---|---|---|---|
| **A. Sole ownership** (default) | Client 100% | Client pays everything | No partnership object; share validator expects 100% client; capital ledger CLIENT-only |
| **B. Partnership + NBV financial involvement** | e.g., 70:30 / 60:40 (client ≥51%) | Shared per **cost-split matrix** (per category: incorporation, govt fees, business capital, top-ups — default pro-rata, overridable) | Deal object + cost-split engine + inter-party balance; NBV capital party-tagged |
| **C. Partnership, NO NBV financial involvement** | e.g., 70:30 / 60:40 (client ≥51%) | Client pays everything; NBV equity = services consideration ("sweat equity") | Deal object; NBV-tagged capital **blocked**; services-consideration clause required in shareholder agreement |

Changing mode later requires RCIC approval + logged reason + new retainer addendum.

**Partnership sub-flow (modes B & C)** — runs inside Track B (incorporation), between
share-structure design and share issuance:

```
DEAL PROPOSED (mode B or C · split % · cost-split matrix if B · fee arrangement)
   ▼
VALIDATORS: client ≥51% ✓ · NBV ≤49% ✓ · splits total 100% ✓ ·
            mode C → zero NBV capital expected ✓ · only client applies under C11 ✓
   ▼
CONFLICT-OF-INTEREST GATE (mandatory, CICC):
   1. Written disclosure of NBV's financial interest      → doc on file
   2. Client advised to obtain Independent Legal Advice    → ILA confirmation or signed waiver
   3. Client's written consent to proceed                  → doc on file
   4. Retainer addendum: fee arrangement vs equity recorded
   ▼
AGREEMENTS: shareholder/partnership agreement (vesting, transfer restrictions,
buyout/exit terms, dividend policy, board seat?; mode C adds the
services-consideration clause) → RCIC + client signatures
   ▼
SHARES ISSUED
   · Mode B: capital contributions traced from BOTH parties into the corporate
     account — NBV deposits party-tagged so the client's "own funds" evidence
     for IRCC stays clean; cost-split engine starts tracking shared costs and
     the inter-party balance (who owes whom, settlements recorded)
   · Mode C: CLIENT-tagged capital only — any NBV-tagged deposit raises a
     mismatch warning (would contradict the no-financial-involvement terms)
   ▼
ACTIVE PARTNERSHIP: distributions/dividends ledger (split per equity ratio) ·
cost-split settlements (B) · annual valuation note · exit events (buyback,
sale, dilution) logged with full history
```

**Important application-strategy note encoded in the system:** the business plan and WP
submission must transparently present the ownership structure (client ≥51%, NBV minority
partner). The capital ledger distinguishes client-sourced capital from NBV-sourced capital,
because IRCC assesses the *client's* investment and control.

## 5. Family & companion cases (one household, many applications)
- **Family Panel completed at onboarding** (stage 1) — every member's bio data, accompanying
  flag, relationship evidence. Family size drives the LICO settlement-funds requirement in
  Track C automatically.
- **Spouse OWP:** auto-eligibility flag (client role TEER 0/1?); one-click companion case
  pre-filled from the member record; own mini-checklist; linked file # (e.g., NBV-2026-0003b).
- **Dependent children:** school-age → Study Permit companion case (+ school-enrolment
  evidence task); younger → visitor record. Alerts when a child approaches the
  dependent-age lock (22) or school age.
- **Per-member processing rows:** police certificates (per age/country), medicals
  (eMedical # each), biometrics (14–79; family appointment grouped; $85/$170 family cap),
  visas issued — the case header shows a family strip with each member's status.
- **Cross-case consistency checker:** addresses, dates, and name spellings compared across
  all the family's applications before any submission — mismatches are a classic
  refusal/procedural-fairness trigger.
- **Post-approval family bundle (auto-tasks):** landing plan (together vs staggered), SIN
  applications, provincial health cards, school registrations, spouse job-search support.
- **PR transition:** opened as linked case (PNP entrepreneur streams by province; system stores province-stream requirement notes; CEC is auto-excluded for C11 time — hard-coded advisory).

## 6. Cross-cutting compliance rules (unchanged + C11 additions)
1. Every stage change → timeline entry; advice entries locked after 24h.
2. RCIC sign-off gates: proposal final, WP submission, extension submission, refusal responses.
3. Trust money rules + monthly reconciliation (CICC). **Client business capital is tracked informationally and never mixed with NBV trust.**
4. Refusal → auto task bundle with written-advice requirement and JR/reapply deadline clocks.
5. Dormancy alerts 14/30 days; WP expiry countdowns at T-180/120/60 days.
6. File closing checklist with +6-year destruction date.
