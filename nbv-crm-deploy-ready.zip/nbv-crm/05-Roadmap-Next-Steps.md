# NBV CRM — Where We Are & What's Next
**Date:** June 12, 2026

## ✅ What you have today
| Asset | Status |
|---|---|
| `01–03` Blueprint docs (PRD, workflows, data model) | Complete — your build contract & training manual |
| `04-prototype.html` | Complete — clickable demo of every module |
| `app/` Production scaffold | **Working & tested**: login/auth, dashboard, leads+quotes, clients+family (LICO/fees auto-calc), case files with Tracks A/B/C, server-enforced compliance gates (A-number, 51%, COI), billing/trust, expenses, users, audit log |

## 🗺 The road from here to "NBV runs on this"

### Sprint 1 (1–2 weeks) — Complete the core workflows  ← IN PROGRESS
1. ✅ **DONE — Lead→Quote→Agreed→Convert flow** (E2E-tested Jun 12): new-lead form, quote
   builder with mandatory reasons + discount authority matrix (server-enforced), Owner
   approval for out-of-authority discounts, AGREED-with-evidence step, conversion gate
   (blocked without agreed quote ✓), auto-creation of client+case+13 folders+M1 invoice
   (30% of agreed fee)+trust deposit+onboarding task bundle. Family form with age auto-rules
   ✓. Trust entry with negative-balance block ✓. A-number recording (gate release) ✓.
   Task add/complete ✓.
2. ✅ **DONE — Document Repository** (12/12 E2E tests passed Jun 12): multipart upload with
   type allowlist + 50 MB cap, SHA-256 hashing (download hash verified = upload hash),
   enforced naming convention, auto-versioning with supersede, locked-document immutability,
   unfiled triage queue + file-to-folder, status lifecycle with invalid-jump blocking,
   folder-level role access (Plan Writer 403 on Banking folder ✓), audit-logged downloads,
   full repository UI page per case.
3. ✅ **DONE — Deadlines + Invoicing/Payments** (9/9 E2E tests passed Jun 12): deadline
   kinds with ADR auto-task at T-5, milestone invoices auto-computed from agreed fee,
   double-billing block, overpayment guard, partial payments, **pay-from-trust earning
   events with auto-paired TRANSFER_TO_OPERATING** (CICC), satisfy-deadline flow.

**🏁 SPRINT 1 COMPLETE** — full core workflow operational end-to-end from the UI.

### Sprint 2 — ✅ COMPLETE (Jun 12)
1. ✅ Invoice/Receipt PDFs — branded, GST split, payments shown, receipt mode when paid.
2. ✅ CICC Trust Reconciliation PDF — per-client balances vs bank, variance $0 verified.
3. ✅ CRA Year-End CSV bundle — summary/invoices/payments/GST+ITC/expenses/unearned-trust.
4. ✅ Deadline & Expiry Scanner — 5 scan types, idempotent, manual button + cron-ready
   (`x-cron-key`); caught the WP T-180 and stale cases on first live run.
5. Deferred to Sprint 3: quote→retainer merge document (template wording needs NBV's
   lawyer-approved retainer text first — see Decisions list).

### Sprint 3 — ✅ COMPLETE (Jun 12) — 17/17 security tests passed
1. ✅ TOTP MFA: enrol/verify, two-step login, mandatory Admin/RCIC, encrypted secrets.
2. ✅ Invite flow: Admin-only, single-use hashed tokens, password policy enforced.
3. ✅ Password reset: no-enumeration, 1-hour token, all-sessions revoked on change.
4. ✅ Field-level AES-256-GCM encryption (passport/UCI) with masked reads + audited reveal.
5. ✅ Cron-key auth for the scanner; backup script (35-day retention) tested.
6. Remaining before real client data (needs NBV decisions/accounts):
   - PostgreSQL + Canada hosting (Vercel+Neon or AWS ca-central-1) — provider switch ready
   - Real email sending (Resend/SES — needs domain DNS)
   - S3 document storage swap (single file: src/lib/storage.ts)
   - Production FIELD_KEY/AUTH_SECRET/CRON_KEY from a secret manager
   - Retainer merge doc (needs NBV's lawyer-approved template text)

### Sprint 4 — NEXT UP (pilot & go-live)
CSV importer for NBV's real client list → parallel-run one real client end-to-end for
2 weeks → staff training → cutover. **Blocked on NBV decisions: hosting, domain/DNS,
fee schedule confirmation, retainer template, real team list.**

### Sprint 2 (1–2 weeks) — Money & compliance outputs
4. **Invoice PDF generation** + receipt PDFs (NBV branding, GST/HST).
5. **Trust reconciliation report** (monthly CICC statement, one click).
6. **CRA year-end export** (invoice/payments registers, ITC summary, CSV).
7. **Quote→retainer merge document** (agreed fee auto-populated).
8. **Nightly job**: deadline/expiry scanner → auto-tasks & dashboard alerts.

### Sprint 3 (1 week) — Hardening for real client data
9. **TOTP MFA enrolment** (authenticator app) — mandatory Admin/RCIC.
10. **User invite & password-reset flows** (email).
11. **Field-level encryption** for passport/UCI/bank fields.
12. **PostgreSQL migration** + hosting in Canada (PIPEDA):
    - Easiest: Vercel (app) + Neon Postgres (ca-central / AWS Canada) + S3 ca-central-1 for documents. ~$25–50/mo total at your size.
13. **Automated backups** + restore test.

### Sprint 4 — Pilot & go-live
14. **Migrate real data**: your current client list, open files, trust balances (I can build a CSV importer).
15. **Pilot 2 weeks**: run ONE new client end-to-end in the system in parallel with your current process.
16. Train staff (the blueprint docs are the manual), then cut over: *every new retainer opens in the CRM from day X*.

### Phase 2 (after go-live, prioritize by pain)
Client portal · Stripe payment links · e-signature · Gmail/Outlook sync · referral-agent module UI · marketing ROI dashboards · QuickBooks export.

## 🔑 Decisions only YOU can make (needed before Sprint 3)
| Decision | Options |
|---|---|
| Hosting budget & ownership | Vercel+Neon (simple, ~$30/mo) vs AWS ca-central-1 (more control) — who owns the accounts? |
| Domain | e.g., `crm.nextbridgeventures.ca` |
| Email sending | For invites/resets/notifications: Resend/SES — needs your domain DNS access |
| Real fee schedule | Confirm $30k list, $22k floor, 30/30/25/15 milestones, discount authority levels |
| Your real templates | Retainer agreement, COI disclosure, ILA waiver — lawyer-drafted once, then merged automatically |
| Who's user #1–5 | Real staff names/emails/roles for setup |

## ⚠️ Honest advice
- **Don't skip the pilot.** Parallel-run one client before trusting it with everything.
- **Trust accounting**: keep your existing reconciliation process until the CRM's report has matched your bank for 2 consecutive months.
- **Have your lawyer review** the partnership COI documents and retainer template before the system starts generating them.
- The CRM **records** compliance; the RCIC remains responsible for it.
